﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_7B
{
    abstract class Military
    {
        public string personnel;
        public string battle_cry;
        public string operational_area;
    }
}
